import { ImageWithFallback } from './figma/ImageWithFallback';

interface ProjectsProps {
  onProjectClick: (id: number) => void;
}

export function Projects({ onProjectClick }: ProjectsProps) {
  const projects = [
    {
      title: 'The Achedemy',
      description: 'is a web app that helps students easily access, share, and organize educational resources in one place.',
      image: 'https://ik.imagekit.io/f0drujfda/iPhone%2016.png',
      tags: ['User Friendly'],
    },
    {
      title: 'Warehouse Inventory',
      description: 'FlowMetrics is a management desktop dashboard designed for supervisors in e-commerce fulfillment centers.',
      image: 'https://ik.imagekit.io/f0drujfda/iPhone%2016%20(2).png',
      tags: ['Easy To Navigate'],
    },
    {
      title: 'ClanHub Manager – Amateur E-sports Team Hub',
      description: 'is an app that helps amateur e-sports teams centralize management, track player performance, schedule practices, and review game replays efficiently.',
      image: 'https://ik.imagekit.io/f0drujfda/iPhone%2016.png',
      tags: ['Eco-Friendly'],
    },
    {
      title: 'WeClean App',
      description: 'WeClean is a mobile app that rewards users for recycling and practicing proper waste management. Users earn points for eco-friendly actions, which can be redeemed for vouchers, discounts, or eco-friendly products.',
      image: 'https://ik.imagekit.io/f0drujfda/Screenshot%20(5).png',
      tags: ['User-Friendly'],
    },
   
  ];

  return (
    <section className="min-h-screen py-24 px-6 relative z-10 flex items-center">
      <div className="max-w-7xl mx-auto w-full">
        <div className="text-center mb-16">
          <h2 className="mb-6 text-transparent bg-clip-text bg-gradient-to-r from-pink-400 via-purple-400 to-cyan-400">
            Projects
          </h2>
          <p className="text-gray-400 text-lg">Click on any project to view details</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <button
              key={index}
              onClick={() => onProjectClick(index)}
              className="group relative bg-gray-800/50 backdrop-blur-sm rounded-2xl overflow-hidden border border-gray-700 hover:border-purple-500/50 transition-all duration-300 hover:scale-[1.03] hover:shadow-2xl hover:shadow-purple-500/20 text-left cursor-pointer"
            >
              {/* Image */}
              <div className="relative h-56 overflow-hidden">
                <ImageWithFallback
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/50 to-transparent"></div>
                
                {/* Click indicator */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
                  <span className="px-6 py-3 bg-purple-500 text-white rounded-full">View Details</span>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="mb-3 text-white group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-purple-400 group-hover:to-cyan-400 transition-all">
                  {project.title}
                </h3>
                <p className="text-gray-400 mb-5 text-sm leading-relaxed line-clamp-2">{project.description}</p>
                
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag, tagIndex) => (
                    <span
                      key={tagIndex}
                      className="px-3 py-1 bg-purple-500/20 border border-purple-400/30 text-purple-300 rounded-full text-xs"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}