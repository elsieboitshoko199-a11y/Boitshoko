import { ArrowLeft, ExternalLink, Github, Calendar, Users } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface ProjectDetailProps {
  projectId: number;
  onBack: () => void;
}

export function ProjectDetail({ projectId, onBack }: ProjectDetailProps) {
  const projectsData = [
    {
      title: 'TheAchedemy',
      description: 'is a web app that helps students easily access, share, and organize educational resources in one place. It features intuitive navigation, clear categorization, search functionality, and collaborative tools, making learning more efficient and interactive. The platform was designed with usability in mind, ensuring a smooth and engaging experience for all users.' ,
      fullDescription: 'a learning resource-sharing web app. I led the process from start to finish, doing user research, planning the structure of the app, designing wireframes, creating the visual interface, building a prototype, and guiding usability testing. The project focused on designing a modern, easy-to-use platform that helps students share and access learning materials.',
      image: 'https://ik.imagekit.io/f0drujfda/iPhone%2016.png',
      tags: ['User Friendly', ],
      duration: '2 weeks',
      team: 'Team of 8',
      role: 'Project Manager',
      challenges: 'Students struggled to find, share, and organize learning resources in one place, and existing platforms were often confusing and uncollaborative.',
      solution: 'Theachedemy provides a user-friendly platform where learners can easily access, share, and organize educational materials while collaborating with peers.',
      liveUrl: 'https://www.figma.com/design/ftRIKUoi7yAQiDXKhFFnjH/TheAchedemy-New-File?node-id=0-1&t=o8vO2j624dShHBad-1',
      githubUr1: 'https://www.figma.com/design/ftRIKUoi7yAQiDXKhFFnjH/TheAchedemy-New-File?node-id=0-1&t=o8vO2j624dShHBad-1', 
    },
    {
      title: 'Warehouse Inventory',
      description: 'Supervisors faced difficulty tracking inventory, monitoring workflows, and identifying bottlenecks, which often caused delays and inefficiencies.',
      fullDescription: 'FlowMetrics is a management desktop dashboard designed for supervisors in e-commerce fulfillment centers. The dashboard provides real-time visual and numerical insights into inventory locations, the status of automated picking robots, and the performance of human pickers. Its goal is to enable supervisors to quickly identify logistical bottlenecks, re-route tasks, and adjust staff allocation, ensuring maximum operational efficiency. By centralizing key operational metrics, FlowMetrics allows for informed, data-driven decision-making, reducing delays and streamlining warehouse workflows.',
      image: 'https://ik.imagekit.io/f0drujfda/iPhone%2016%20(2).png',
      tags: ['Easy to Navigate'],
      duration: '3 weeks',
      team: 'Solo Project',
      role: 'Full Stack Developer & Designer',
      challenges: 'Supervisors faced difficulty tracking inventory, monitoring workflows, and identifying bottlenecks, which often caused delays and inefficiencies.',
      solution: 'FlowMetrics centralized real-time data and visualized key metrics, enabling supervisors to quickly spot issues, re-route tasks, and optimize operations for improved efficiency.',
      liveUrl: 'https://www.figma.com/design/yut6aBY8ucVFZ6qMJshf1i/Untitled?node-id=0-1&t=jmkbGpULHnRNGelv-1',
      githubUrl: 'https://www.figma.com/design/yut6aBY8ucVFZ6qMJshf1i/Untitled?node-id=0-1&t=jmkbGpULHnRNGelv-1',
    },
    {
      title: 'ClanHub Manager – Amateur E-sports Team Hub',
      description: 'is an app that helps amateur e-sports teams centralize management, track player performance, schedule practices, and review game replays efficiently.',
      fullDescription: 'ClanHub Manager is a mobile and web app designed for amateur e-sports teams to streamline team management and improve performance. The platform allows teams to schedule practices, track individual and team performance statistics, and review game replays with time-stamped clips for multiple team members. By centralizing these features in one platform, ClanHub Manager simplifies coordination, enhances team communication, and supports data-driven improvements in gameplay. The app aims to save time, increase team efficiency, and provide a professional approach to amateur e-sports management.',
      image: 'https://ik.imagekit.io/f0drujfda/iPhone%2016.png',
      tags: ['Eco-Friendly'],
      duration: '3 months',
      team: 'Solo Project',
      role: 'Full Stack Developer & Designer',
      challenges: 'Amateur e-sports teams often struggle with scattered scheduling, limited access to performance data, and difficulty reviewing and analyzing game replays efficiently.',
      solution: 'ClanHub Manager centralizes scheduling, performance tracking, and replay analysis in one platform, enabling teams to coordinate practices, monitor progress, and review gameplay quickly and effectively.',
      liveUrl: 'https://www.figma.com/design/yut6aBY8ucVFZ6qMJshf1i/Untitled?node-id=0-1&t=jmkbGpULHnRNGelv-1',
      githubUrl: 'https://www.figma.com/design/yut6aBY8ucVFZ6qMJshf1i/Untitled?node-id=0-1&t=jmkbGpULHnRNGelv-1',
    },
    {
      title: 'WeClean App',
      description: 'WeClean is a mobile app that rewards users for recycling and practicing proper waste management. Users earn points for eco-friendly actions, which can be redeemed for vouchers, discounts, or eco-friendly products.',
      fullDescription: 'A comprehensive task management platform for teams of all sizes. Features include real-time collaboration, task assignments, deadline tracking, team chat, file sharing, and progress visualization. The app supports multiple project views including kanban boards and Gantt charts.',
      image: 'https://ik.imagekit.io/f0drujfda/Screenshot%20(5).png',
      tags: ['User-Friendly'],
      duration: '5 months',
      team: 'Team of 3',
      role: 'Frontend Lead',
      challenges: 'Many people are unaware of the importance of recycling or lack the motivation to participate in eco-friendly practices, which leads to low engagement. Tracking and verifying individual recycling activities can also be difficult, making it hard to measure impact accurately. Additionally, a lack of knowledge about proper waste management and recycling techniques often results in improper disposal of waste. Finally, limited community involvement can prevent collective action, as individuals may feel disconnected from local clean-up efforts and sustainability initiatives.',
      solution: 'WeClean addresses these challenges by combining motivation, education, and community engagement. The app uses a gamified rewards system, allowing users to earn points for recycling activities, which can be redeemed for vouchers, discounts, or eco-friendly products, encouraging consistent participation. It also tracks and verifies activities through item scanning and activity logging, ensuring accountability. Educational content teaches proper waste management and recycling techniques, while community features, such as clean-up events and social sharing, foster collaboration and a culture of sustainability.',
      liveUrl: 'https://www.figma.com/proto/uvU16FNJKHWTfflgqCviwv/WE-CLEAN-FINAL?node-id=0-1&t=rLGZL6VZ5GGTgGzM-1',
      githubUrl: 'https://www.figma.com/proto/uvU16FNJKHWTfflgqCviwv/WE-CLEAN-FINAL?node-id=0-1&t=rLGZL6VZ5GGTgGzM-1',
    },
    
  ];

  const project = projectsData[projectId];

  return (
    <div className="min-h-screen bg-gray-900 relative overflow-x-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-80 h-80 bg-cyan-500/20 rounded-full blur-3xl"></div>
      </div>

      <div className="relative z-10">
        {/* Back button */}
        <button
          onClick={onBack}
          className="fixed top-6 left-6 px-6 py-3 bg-gray-800/80 backdrop-blur-sm border border-gray-700 hover:border-purple-500/50 text-white rounded-full flex items-center gap-2 transition-all hover:scale-105 hover:shadow-lg hover:shadow-purple-500/20 z-50"
        >
          <ArrowLeft size={20} />
          <span>Back to Projects</span>
        </button>

        {/* Project content */}
        <div className="max-w-5xl mx-auto px-6 py-24">
          {/* Hero image */}
          <div className="relative h-96 rounded-3xl overflow-hidden mb-12 border border-gray-700">
            <ImageWithFallback
              src={project.image}
              alt={project.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/50 to-transparent"></div>
            <ImageWithFallback 
              src="https://instasize.com/p/28f412d55753721c1eac8d5364ca795eb84831d5c7ccaa29a47174c753e0f7d3"
              alt="Overlay"
              className="absolute inset-0 w-full h-full object-cover opacity-60"
            />
          </div>

          {/* Title and description */}
          <div className="mb-12">
            <h1 className="text-5xl mb-6 text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400">
              {project.title}
            </h1>
            <p className="text-xl text-gray-300 leading-relaxed mb-8">{project.fullDescription}</p>
            
            {/* Tags */}
            <div className="flex flex-wrap gap-3 mb-8">
              {project.tags.map((tag, index) => (
                <span
                  key={index}
                  className="px-4 py-2 bg-purple-500/20 border border-purple-400/30 text-purple-300 rounded-full"
                >
                  {tag}
                </span>
              ))}
            </div>

            {/* Links */}
            <div className="flex gap-4">
              <a
                href={project.liveUrl}
                className="px-6 py-3 bg-gradient-to-r from-purple-500 to-cyan-500 text-white rounded-lg hover:shadow-lg hover:shadow-purple-500/50 transition-all hover:scale-105 flex items-center gap-2"
              >
                <ExternalLink size={20} />
                <span>View Live Demo</span>
              </a>
              <a
                href={project.githubUrl}
                className="px-6 py-3 bg-gray-800/50 border border-gray-700 text-white rounded-lg hover:border-purple-500/50 transition-all hover:scale-105 flex items-center gap-2"
              >
                <Github size={20} />
                <span>View Code</span>
              </a>
            </div>
          </div>

          {/* Project details grid */}
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <div className="p-6 bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-2xl">
              <div className="flex items-center gap-3 mb-3">
                <Calendar className="text-purple-400" size={24} />
                <h3 className="text-white">Duration</h3>
              </div>
              <p className="text-gray-300">{project.duration}</p>
            </div>

            <div className="p-6 bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-2xl">
              <div className="flex items-center gap-3 mb-3">
                <Users className="text-cyan-400" size={24} />
                <h3 className="text-white">Team</h3>
              </div>
              <p className="text-gray-300">{project.team}</p>
            </div>
          </div>

          {/* Challenges and solutions */}
          <div className="space-y-8">
            <div className="p-8 bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-2xl">
              <h3 className="text-white mb-4">My Role</h3>
              <p className="text-gray-300 text-lg">{project.role}</p>
            </div>

            <div className="p-8 bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-2xl">
              <h3 className="text-white mb-4">Challenges</h3>
              <p className="text-gray-300 text-lg">{project.challenges}</p>
            </div>

            <div className="p-8 bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-2xl">
              <h3 className="text-white mb-4">Solution</h3>
              <p className="text-gray-300 text-lg">{project.solution}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}