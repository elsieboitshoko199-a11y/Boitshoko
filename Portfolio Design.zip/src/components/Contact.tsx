import { Mail, Linkedin, Github, Twitter, Send, Instagram, Phone } from 'lucide-react';
import { useState } from 'react';

export function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock form submission
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setFormData({ name: '', email: '', message: '' });
    }, 3000);
  };

  const socialLinks = [
    { 
      icon: <Mail size={20} />, 
      label: 'Email', 
      url: 'elsieboitshoko199@gmail.com',
      color: 'from-red-400 to-pink-500'
    },
    { 
      icon: <Linkedin size={20} />, 
      label: 'LinkedIn', 
      url: 'Boitshoko Moema',
      color: 'from-blue-400 to-cyan-500'
    },
    { 
      icon: <Phone size={20} />, 
      label: 'Contact', 
      url: '0645259802',
      color: 'from-gray-400 to-gray-600'
    },
    { 
      icon: <Instagram size={20} />, 
      label: 'Instagram', 
      url: 'Boitshoko Moema',
      color: 'from-cyan-400 to-blue-500'
    },
  ];

  return (
    <section className="min-h-screen py-24 px-6 relative z-10 flex items-center">
      <div className="max-w-4xl mx-auto w-full">
        <div className="text-center mb-16">
          <h2 className="mb-6 text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400">
            Get In Touch
          </h2>
          <p className="text-gray-300 text-lg">
            Let's collaborate on your next project
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-10">
          {/* Contact Form */}
          <div className="relative p-8 rounded-2xl bg-gray-800/50 backdrop-blur-sm border border-gray-700 hover:border-purple-500/30 transition-all">
            <div className="relative">
              {submitted ? (
                <div className="h-full min-h-[350px] flex items-center justify-center">
                  <div className="text-center">
                    <div className="relative inline-block mb-6">
                      <div className="absolute inset-0 bg-green-400 rounded-full blur-xl opacity-50 animate-pulse"></div>
                      <div className="relative w-16 h-16 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full flex items-center justify-center shadow-lg">
                        <svg
                          className="w-8 h-8 text-white"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M5 13l4 4L19 7"
                          />
                        </svg>
                      </div>
                    </div>
                    <h3 className="text-white mb-2">Message Sent!</h3>
                    <p className="text-gray-400 text-sm">I'll get back to you soon</p>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div>
                    <label htmlFor="name" className="block text-gray-300 mb-2 text-sm">
                      Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-3 bg-gray-900/50 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-purple-400 focus:shadow-lg focus:shadow-purple-500/20 transition-all"
                      placeholder="Your name"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-gray-300 mb-2 text-sm">
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-3 bg-gray-900/50 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-purple-400 focus:shadow-lg focus:shadow-purple-500/20 transition-all"
                      placeholder="your@email.com"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="message" className="block text-gray-300 mb-2 text-sm">
                      Message
                    </label>
                    <textarea
                      id="message"
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      rows={5}
                      className="w-full px-4 py-3 bg-gray-900/50 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-purple-400 focus:shadow-lg focus:shadow-purple-500/20 transition-all resize-none"
                      placeholder="Your message..."
                      required
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full px-6 py-3 bg-gradient-to-r from-purple-500 to-cyan-500 text-white rounded-lg hover:shadow-xl hover:shadow-purple-500/50 transition-all hover:scale-[1.02] flex items-center justify-center gap-2"
                  >
                    Send Message
                    <Send size={16} />
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* Social Links */}
          <div className="space-y-4">
            <h3 className="text-white mb-6 text-xl">Connect With Me</h3>
            {socialLinks.map((link, index) => (
              <a
                key={index}
                href={link.url}
                className="group block relative p-5 bg-gray-800/50 backdrop-blur-sm rounded-xl border border-gray-700 hover:border-purple-500/50 transition-all duration-300 hover:scale-[1.03] hover:shadow-lg hover:shadow-purple-500/20"
              >
                <div className={`absolute inset-0 bg-gradient-to-r ${link.color} rounded-xl opacity-0 group-hover:opacity-10 transition-opacity`}></div>
                <div className="relative flex items-center gap-4">
                  <div className={`w-12 h-12 bg-gradient-to-br ${link.color} rounded-lg flex items-center justify-center text-white shadow-lg group-hover:scale-110 transition-transform`}>
                    {link.icon}
                  </div>
                  <span className="text-gray-300 group-hover:text-white transition-colors">
                    {link.label}
                  </span>
                </div>
              </a>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="mt-20 pt-8 border-t border-gray-800 text-center">
          <p className="text-gray-500 text-sm">
            &copy; 2025 Boitshoko Moema. All rights reserved.
          </p>
        </div>
      </div>
    </section>
  );
}