import { Code2, Palette, Rocket, Zap } from 'lucide-react';

export function About() {
  const skills = [
    'UI/UX Design',
    'Web Development',
    'Mobile App Design',
    'User Research',
    'Prototyping',
    'Interaction Design',
  ];

  const software = [
    { name: 'Figma', color: 'from-purple-500 to-pink-500' },
    { name: 'Flutterflow', color: 'from-blue-500 to-cyan-500' },
    { name: 'Canva', color: 'from-cyan-500 to-teal-500' },
    { name: 'Adobe Photoshop', color: 'from-blue-600 to-indigo-600' },
    { name: 'Adobe Illustrator', color: 'from-orange-500 to-yellow-500' },
  ];

  return (
    <section className="min-h-screen py-24 px-6 relative z-10 flex items-center">
      <div className="max-w-4xl mx-auto w-full">
        {/* About Me */}
        <div className="text-center mb-20">
          <h2 className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-cyan-400 mb-8">
            About Me
          </h2>
          <p className="text-xl text-gray-300 leading-relaxed max-w-3xl mx-auto">
            I am a vibrant, confident, and creative individual whose presence fills every space she enters. Known for my bold personality and authentic energy, I approaches life and work with passion and purpose. My enthusiasm for learning and self-expression drives me to explore new ideas and challenge the ordinary.
            
            I am a <span className="text-purple-400">curious designer and developer</span> who loves turning ideas into interactive experiences. 
            My path in the HCI program shaped how I see design, as a bridge between people and technology. 
            Every project I take on challenges me to think differently, solve real problems, and express creativity through function and form.
          </p>
        </div>

        {/* Skills Section */}
        <div className="mb-20">
          <h3 className="text-white mb-8 text-center">Skills</h3>
          <div className="flex flex-wrap gap-4 justify-center">
            {skills.map((skill, index) => (
              <div
                key={index}
                className="px-8 py-4 bg-gray-800/50 backdrop-blur-sm border border-gray-700 hover:border-purple-500/50 rounded-full text-gray-300 hover:text-white transition-all hover:scale-105 hover:shadow-lg hover:shadow-purple-500/20 text-lg"
              >
                {skill}
              </div>
            ))}
          </div>
        </div>

        {/* Software I Use Section */}
        <div>
          <h3 className="text-white mb-8 text-center">Software I Use</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-6 max-w-4xl mx-auto">
            {software.map((item, index) => (
              <div
                key={index}
                className="group relative p-8 rounded-2xl bg-gray-800/50 backdrop-blur-sm border border-gray-700 hover:border-purple-500/50 transition-all duration-300 hover:scale-110 text-center hover:shadow-xl hover:shadow-purple-500/20"
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${item.color} rounded-2xl opacity-0 group-hover:opacity-10 transition-opacity blur-xl`}></div>
                <div className="relative">
                  <div className={`w-20 h-20 rounded-2xl bg-gradient-to-br ${item.color} mx-auto mb-4 group-hover:rotate-12 transition-transform shadow-lg`}></div>
                  <p className="text-sm text-gray-300 group-hover:text-white transition-colors">{item.name}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}