import { useState } from 'react';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Projects } from './components/Projects';
import { Contact } from './components/Contact';
import { FloatingShapes } from './components/FloatingShapes';
import { ProjectDetail } from './components/ProjectDetail';

export default function App() {
  const [selectedProject, setSelectedProject] = useState<number | null>(null);

  if (selectedProject !== null) {
    return <ProjectDetail projectId={selectedProject} onBack={() => setSelectedProject(null)} />;
  }

  return (
    <div className="min-h-screen bg-gray-900 overflow-x-hidden">
      <FloatingShapes />
      <Hero />
      <About />
      <Projects onProjectClick={setSelectedProject} />
      <Contact />
    </div>
  );
}