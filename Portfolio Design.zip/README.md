
  # Portfolio Design

  This is a code bundle for Portfolio Design. The original project is available at https://www.figma.com/design/9ijlwCzEW84NjuHJ9GoQq6/Portfolio-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  