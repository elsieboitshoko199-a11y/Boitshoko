# Boitshoko Moema - Portfolio

A modern, single-page portfolio website for Creative Developer & Designer Boitshoko Moema.

## Features

- **Single Page Design**: Smooth scrolling through Home, About, Projects, and Contact sections
- **Modern Animations**: Subtle gradients and motion effects throughout
- **Project Showcase**: Interactive project cards with detailed project pages
- **Responsive Design**: Works seamlessly across all devices
- **Contact Form**: Integrated contact form with social media links

## Tech Stack

- React 18
- TypeScript
- Tailwind CSS v4
- Vite
- Lucide React (icons)
- Motion (animations)

## Getting Started

### Prerequisites

- Node.js 18+ and npm

### Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```

### Development

Run the development server:

```bash
npm run dev
```

Open [http://localhost:5173](http://localhost:5173) in your browser.

### Build

Build for production:

```bash
npm run build
```

Preview production build:

```bash
npm run preview
```

## Deployment on Vercel

### Option 1: Deploy via Vercel Dashboard

1. Push your code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Click "New Project"
4. Import your GitHub repository
5. Vercel will auto-detect the settings
6. Click "Deploy"

### Option 2: Deploy via Vercel CLI

1. Install Vercel CLI:
   ```bash
   npm i -g vercel
   ```

2. Deploy:
   ```bash
   vercel
   ```

3. Follow the prompts to complete deployment

## Project Structure

```
/
├── components/          # React components
│   ├── About.tsx       # About section
│   ├── Contact.tsx     # Contact section with form
│   ├── Hero.tsx        # Hero section
│   ├── Projects.tsx    # Projects grid
│   ├── ProjectDetail.tsx # Individual project pages
│   └── FloatingShapes.tsx # Background animations
├── styles/
│   └── globals.css     # Global styles and Tailwind config
├── App.tsx             # Main app component
├── main.tsx           # App entry point
└── index.html         # HTML template
```

## Contact

Boitshoko Moema
- Email: elsieboitshoko199@gmail.com
- Phone: 0645259802

## License

© 2025 Boitshoko Moema. All rights reserved.
